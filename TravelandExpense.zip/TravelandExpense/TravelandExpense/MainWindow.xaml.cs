﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Configuration;

namespace TravelandExpense
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ImageBrush_ImageFailed(object sender, ExceptionRoutedEventArgs e)
        {

        }

        private void Login_button(object sender, RoutedEventArgs e)
        {
            //        if (txtUsername.Text.Length == 0)
            //        {
            //            errormessage.Text = "Enter an email.";
            //            txtUsername.Focus();
            //        }
            //        else if (!Regex.IsMatch(txtUsername.Text, @"^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"))
            //        {
            //            errormessage.Text = "Enter a valid email.";
            //            txtUsername.Select(0, txtUsername.Text.Length);
            //            txtUsername.Focus();
            //        }
            //        else
            //        {
            //            string email = txtUsername.Text;
            //            string password = pwdbox.Password;
            //            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString); ;
            //            con.Open();
            //            SqlCommand cmd = new SqlCommand("Select * from Registration_172474 where Email='" + email + "'  and Password='" + password + "'", con);
            //            cmd.CommandType = CommandType.Text;
            //            SqlDataAdapter adapter = new SqlDataAdapter();
            //            adapter.SelectCommand = cmd;
            //            DataSet dataSet = new DataSet();
            //            adapter.Fill(dataSet);
            //            if (dataSet.Tables[0].Rows.Count > 0)
            //            {
            //                string username = dataSet.Tables[0].Rows[0]["FirstName"].ToString() + " " + dataSet.Tables[0].Rows[0]["LastName"].ToString();
            //                welcome.TextBlockName.Text = username;//Sending value from one form to another form.  
            //                welcome.Show();
            //                Close();
            //            }
            //            else
            //            {
            //                errormessage.Text = "Sorry! Please enter existing emailid/password.";
            //            }
            //            con.Close();
            //        }
            //    }
            //}

            //    private void Admin_Button(object sender, RoutedEventArgs e)
            //    {
            //        Administrator administrator = new Administrator();
            //        administrator.Show();
            //    }
            //}
        }
    }
}
