﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Controls_Entity;
using Controls_Exception;

namespace Controls_DAL
{
    public class EmployeeDAL
    {
        public static int InsertEmployee(EmployeeEntity Emp)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "InsertEmployeeDetail1";

                cmd.Parameters.AddWithValue("@Employee_NO", Emp.Employee_NO);
                cmd.Parameters.AddWithValue("@Employee_Name", Emp.Employee_Name);
                cmd.Parameters.AddWithValue("@Employee_DeptNo", Emp.Employee_DeptNo);
                cmd.Parameters.AddWithValue("@Employee_DOB", Emp.Employee_DOB);
                cmd.Parameters.AddWithValue("@Employee_Address", Emp.Employee_Address);
                cmd.Parameters.AddWithValue("@Employee_Gender", Emp.Employee_Gender);
                cmd.Parameters.AddWithValue("@Employee_Domain", Emp.Employee_Domain);
                cmd.Parameters.AddWithValue("@Employee_HQual", Emp.Employee_HQual);
                cmd.Parameters.AddWithValue("@Employee_Language", Emp.Employee_Language);
                cmd.Parameters.AddWithValue("@Employee_PF_Location", Emp.Employee_PF_Location);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public static int UpdateEmployee(EmployeeEntity Emp)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "UpdateEmployeeDetails1";

                cmd.Parameters.AddWithValue("@Employee_NO", Emp.Employee_NO);
                cmd.Parameters.AddWithValue("@Employee_DeptNo", Emp.Employee_DeptNo);
                cmd.Parameters.AddWithValue("@Employee_Address", Emp.Employee_Address);
                cmd.Parameters.AddWithValue("@Employee_Language", Emp.Employee_Language);
                cmd.Parameters.AddWithValue("@Employee_PF_Location", Emp.Employee_PF_Location);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public static int DeleteEmployee(int Employee_NO)
        {
            int recordsAffected = 0;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "DeleteEmployeeDetails2";

                cmd.Parameters.AddWithValue("@Employee_NO", Employee_NO);
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }
        public static EmployeeEntity SearchEmployee(int Employee_NO)
        {
            EmployeeEntity Emp = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "SearchEmployeeDetails1";

                cmd.Parameters.AddWithValue("@Employee_NO", Employee_NO);
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    Emp = new EmployeeEntity();
                    dr.Read();
                    Emp.Employee_NO = Convert.ToInt32(dr["Employee_No"]);
                    Emp.Employee_Name = dr["Employee_Name"].ToString();
                    Emp.Employee_DeptNo = Convert.ToInt32(dr["Employee_DeptNo"]);
                    Emp.Employee_DOB = Convert.ToDateTime(dr["Employee_DOB"]);
                    Emp.Employee_Address = dr["Employee_Address"].ToString();
                    Emp.Employee_Gender = dr["Employee_Gender"].ToString();
                    Emp.Employee_Domain = dr["Employee_Domain"].ToString();
                    Emp.Employee_HQual = dr["Employee_HQual"].ToString();
                    Emp.Employee_Language = dr["Employee_Language"].ToString();
                    Emp.Employee_PF_Location = dr["Employee_PF_Location"].ToString();
                    

                    
                }
                else
                {
                    throw new ValidationException("Record not found");
                }
                cmd.Connection.Close();
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return Emp;


        }
        public static List<EmployeeEntity> RetrieveEmployee()
        {
            List<EmployeeEntity> EmpList = null;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "DisplayEmployeeDetails2";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    EmpList = new List<EmployeeEntity>();
                    while (dr.Read())
                    {
                        EmployeeEntity Emp = new EmployeeEntity();
                        Emp.Employee_NO = (int)dr["Employee_No"];
                        Emp.Employee_Name = dr["Employee_Name"].ToString();
                        Emp.Employee_DeptNo = (int)dr["Employee_DeptNo"];
                        Emp.Employee_DOB = Convert.ToDateTime(dr["Employee_DOB"]);
                        Emp.Employee_Address = dr["Employee_Address"].ToString();
                        Emp.Employee_Gender = dr["Employee_Gender"].ToString();
                        Emp.Employee_Domain = dr["Employee_Domain"].ToString();
                        Emp.Employee_HQual = dr["Employee_HQual"].ToString();
                        Emp.Employee_Language = dr["Employee_Language"].ToString();
                        Emp.Employee_PF_Location = dr["Employee_PF_Location"].ToString();

                        EmpList.Add(Emp);
                    }
                }
                else
                    throw new ValidationException("Record not available");
                cmd.Connection.Close();
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return EmpList;
        }
    }

}