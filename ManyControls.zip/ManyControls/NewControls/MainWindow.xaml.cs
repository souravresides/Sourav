﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Controls_Entity;
using Controls_BAL;
using Controls_Exception;

namespace NewControls
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        SqlCommand cmd;
        SqlDataReader dr;
        public MainWindow()
        {
            InitializeComponent();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeDetails"].ConnectionString);
        }
        public void Clear()
        {
            txtEmpNo.Text = "";
            txtEmpname.Text = "";
            txtDeptNo.Text = "";
            txtDOB.Text = "";
            txtAddress.Text = "";
            rbGenderM.IsChecked = false;
            rbGenderF.IsChecked = false;
            chkbx1.IsChecked = false;
            chkbx2.IsChecked = false;
            chkbx3.IsChecked = false;
            chkbx4.IsChecked = false;
            chkbx5.IsChecked = false;
            chkbx6.IsChecked = false;
            chkbx7.IsChecked = false;
            chkbx8.IsChecked = false;
            chkbx9.IsChecked = false;
            chkbx10.IsChecked = false;

            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
            txtEmpNo.IsReadOnly = false;
            txtEmpname.IsReadOnly = false;
            txtDOB.IsEnabled = true;
        }

        public void Show()
        {
            try
            {
                List<EmployeeEntity> empList = EmployeeBAL.RetrieveEmployee();

                if (empList == null || empList.Count <= 0)
                    throw new ValidationException("Records not available");
                else
                {
                    digrid.DataContext = empList;
                }
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeEntity Emp = new EmployeeEntity();

                Emp.Employee_NO = Convert.ToInt32(txtEmpNo.Text);
                Emp.Employee_Name = txtEmpname.Text;
                Emp.Employee_DeptNo = Convert.ToInt32(txtDeptNo.Text);
                Emp.Employee_DOB = Convert.ToDateTime(txtDOB.Text);
                Emp.Employee_Address = txtAddress.Text;
                

                string gender = string.Empty;
                if ((bool)rbGenderM.IsChecked)
                    gender = rbGenderM.Content.ToString();
                else
                    if ((bool)rbGenderF.IsChecked)
                    gender = rbGenderF.Content.ToString();
                Emp.Employee_Gender = gender;


                string qualification = string.Empty;
                if ((bool)rbbutton3.IsChecked)
                    qualification = rbbutton3.Content.ToString();
                else
                    if ((bool)rbbutton4.IsChecked)
                    qualification = rbbutton4.Content.ToString();
                else
                    if ((bool)rbbutton5.IsChecked)
                    qualification = rbbutton5.Content.ToString();
                Emp.Employee_HQual = qualification;

                //StringBuilder sbData = new StringBuilder();
                //string listbx = string.Empty;
                //ListBoxItem it = (ListBoxItem)lb1.SelectedItem;
                //if(it != null)
                //    listbx = it.Content.ToString();
                //Emp.Employee_PF_Location = listbx;

                //CheckBox
                string checkbox = string.Empty;
                // CheckBox chkbx = 
                if ((bool)chkbx1.IsChecked)
                    checkbox += chkbx1.Content.ToString()+",";
                if ((bool)chkbx2.IsChecked)
                    checkbox += chkbx2.Content.ToString() + ",";
                if ((bool)chkbx3.IsChecked)
                    checkbox += chkbx3.Content.ToString() +",";
                if ((bool)chkbx4.IsChecked)
                    checkbox += chkbx4.Content.ToString() +",";
                if ((bool)chkbx5.IsChecked)
                    checkbox += chkbx5.Content.ToString();
                Emp.Employee_Domain = checkbox;

                string checkbox1 = string.Empty;
                // CheckBox chkbx = 
                if ((bool)chkbx6.IsChecked)
                    checkbox1 += chkbx6.Content.ToString() + ",";
                if ((bool)chkbx7.IsChecked)
                    checkbox1 += chkbx7.Content.ToString() + ",";
                if ((bool)chkbx8.IsChecked)
                    checkbox1 += chkbx8.Content.ToString() +",";
                if ((bool)chkbx9.IsChecked)
                    checkbox1 += chkbx9.Content.ToString() + ",";
                if ((bool)chkbx10.IsChecked)
                    checkbox1 += chkbx10.Content.ToString();
                Emp.Employee_Language = checkbox1;
                //ComboBox
                Emp.Employee_PF_Location = ((ComboBoxItem)cmbox.SelectedItem).Content.ToString();


                int recordsAffected = EmployeeBAL.InsertEmployee(Emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new ValidationException("Record not inserted");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empCode = Convert.ToInt32(txtEmpNo.Text);

                EmployeeEntity emp = EmployeeBAL.SearchEmployee(empCode);

                if (emp != null)
                {
                    txtEmpNo.Text = emp.Employee_NO.ToString();
                    txtEmpname.Text = emp.Employee_Name;
                    txtDeptNo.Text = emp.Employee_DeptNo.ToString();
                    txtDOB.Text = emp.Employee_DOB.ToString();
                    txtAddress.Text = emp.Employee_Address;

                    if (emp.Employee_Gender == "Male")
                    {
                        rbGenderM.IsChecked = true;
                    }
                    else if(emp.Employee_Gender == "Female")
                    {
                        rbGenderF.IsChecked = true;
                    }

                    if (emp.Employee_HQual == "Under Graduate")
                    {
                        rbbutton3.IsChecked = true;
                    }
                    else if (emp.Employee_HQual == "Graduate")
                    {
                        rbbutton4.IsChecked = true;
                    }
                    else if(emp.Employee_HQual == "Post Graduate")
                    {
                        rbbutton5.IsChecked = true;
                    }

                    string[] vals = emp.Employee_Domain.Split(',');
                    foreach (var item in vals)
                    {
                        if (item == "Java")
                            chkbx1.IsChecked = true;
                        if (item == "Data Structure")
                            chkbx2.IsChecked = true;
                        if (item == "C#")
                            chkbx3.IsChecked = true;
                        if (item == "C++")
                            chkbx4.IsChecked = true;
                        if (item == "HTML")
                            chkbx5.IsChecked = true;
                    }

                    string[] valus = emp.Employee_Language.Split(',');
                    foreach (var items in valus)
                    {
                        if (items == "British English")
                            chkbx6.IsChecked = true;
                        if (items == "Hindi")
                            chkbx7.IsChecked = true;
                        if (items == "Bengali")
                            chkbx8.IsChecked = true;
                        if (items == "Marathi")
                            chkbx9.IsChecked = true;
                        if (items == "Odia")
                            chkbx10.IsChecked = true;
                    }
                    string cmbx = string.Empty;
                    ComboBoxItem it = (ComboBoxItem)cmbox.SelectedItem;
                    if (it != null)
                        cmbx = it.Content.ToString();
                    emp.Employee_PF_Location = cmbx;


                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    txtEmpNo.IsReadOnly = true;
                    txtEmpname.IsReadOnly = true;
                    txtDOB.IsEnabled = false;

                    MessageBox.Show("Employee Number: "+emp.Employee_NO+"\n"+"Name: "+emp.Employee_Name+"\n"+ "Department Number: " + emp.Employee_DeptNo + "\n"+ "Date of Birth: " + emp.Employee_DOB + "\n"+ "Address: " + emp.Employee_Address + "\n"+ "Gender : " + emp.Employee_Gender + "\n"+ "Highest Qualification: " + emp.Employee_HQual + "\n"+ "Preferred Location: " + emp.Employee_PF_Location + "\n");
                }
                else
                    throw new ValidationException("Student record not found");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EmployeeEntity emp = new EmployeeEntity();

                emp.Employee_NO = Convert.ToInt32(txtEmpNo.Text);
                emp.Employee_Name = txtEmpname.Text;
                emp.Employee_DeptNo = Convert.ToInt32(txtDeptNo.Text);
               
                emp.Employee_Address = txtAddress.Text;

                string checkbox1 = string.Empty;
                // CheckBox chkbx = 
                if ((bool)chkbx6.IsChecked)
                    checkbox1 += chkbx6.Content.ToString() + ",";
                if ((bool)chkbx7.IsChecked)
                    checkbox1 += chkbx7.Content.ToString() + ",";
                if ((bool)chkbx8.IsChecked)
                    checkbox1 += chkbx8.Content.ToString() + ",";
                if ((bool)chkbx9.IsChecked)
                    checkbox1 += chkbx9.Content.ToString() + ",";
                if ((bool)chkbx10.IsChecked)
                    checkbox1 += chkbx10.Content.ToString();
                emp.Employee_Language = checkbox1;
                //ComboBox
                emp.Employee_PF_Location = cmbox.SelectionBoxItem.ToString();
               // emp.Employee_PF_Location = ((ComboBoxItem)cmbox.SelectedItem).Content.ToString();

                int recordsAffected = EmployeeBAL.UpdateEmployee(emp);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Clear();
                }
                else
                    throw new ValidationException("Record not updated");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empCode = Convert.ToInt32(txtEmpNo.Text);

                int recordsAffected = EmployeeBAL.DeleteEmployee(empCode);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    Clear();
                }
                else
                    throw new ValidationException("Record not deleted");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        private void BtnCount_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT COUNT(*) FROM Sourav_Master1", con);
            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            MessageBox.Show("Total number of Employees are :" + count);
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }


    }
    }