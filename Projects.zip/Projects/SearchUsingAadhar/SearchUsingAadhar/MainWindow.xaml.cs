﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Aadhar_Entities;
using Aadhar_Exception;
using Aadhar_DAL;
using Aadhar_BAL;

namespace SearchUsingAadhar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds = new DataSet();
        SqlCommand cmd;
        SqlDataReader dr;
        public MainWindow()
        {
            InitializeComponent();
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
        }
        public void ClearAll()
        {
            txtAdhar.Text = "";
            txtEmpID.Text = "";
            txtEmpName.Text = "";
            txtDept.Text = "";
            txtDOB.Text = "";
            txtEmail.Text = " ";
            txtAddress.Text = " ";
            txtCity.Text = " ";
            txtState.Text = " ";
            txtPhone.Text = " ";


            Update.IsEnabled = false;
            Delete.IsEnabled = false;
            txtAdhar.IsReadOnly = false;
            txtEmpName.IsReadOnly = false;
            txtDOB.IsEnabled = true;
        }
        public void ShowAll()
        {
            try
            {
                List<Entities> studList = AadharBAL.RetrieveStudent();

                if (studList == null || studList.Count <= 0)
                    throw new ValidationException("Records not available");
                else
                {
                    datagrid.ItemsSource = studList.ToList();
                }
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ShowAll();
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string studCode = (txtAdhar.Text).ToString();

                Entities stud = AadharBAL.SearchStudent(studCode);

                if (stud != null)
                {
                    txtAdhar.Text = stud.Aadhar_Number.ToString();
                    txtEmpID.Text = stud.Employee_ID.ToString();
                    txtEmpName.Text = stud.Employee_Name;
                    txtDept.Text = stud.Dept_No.ToString();
                    txtDOB.Text = stud.DOB.ToString();
                    txtEmail.Text = stud.Email;
                    txtAddress.Text = stud.Address;
                    txtCity.Text = stud.City;
                    txtState.Text = stud.State;
                    txtPhone.Text = stud.Phone_Number.ToString();

                    Update.IsEnabled = true;
                    Delete.IsEnabled = true;
                    txtAdhar.IsReadOnly = true;
                    txtEmpName.IsReadOnly = true;
                    txtDOB.IsEnabled = false;
                }
                else
                    throw new ValidationException("Student record not found");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void Insert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities stud = new Entities();

                stud.Aadhar_Number = txtAdhar.Text;
                stud.Employee_ID =Convert.ToInt32(txtEmpID.Text);
                stud.Employee_Name = txtEmpName.Text;
                stud.Dept_No = Convert.ToInt32(txtDept.Text);
                stud.DOB = Convert.ToDateTime(txtDOB.Text);
                stud.Email = txtEmail.Text;
                stud.Address = txtAddress.Text;
                stud.City = txtCity.Text;
                stud.State = txtState.Text;
                stud.Phone_Number = txtPhone.Text;

                string gender = string.Empty;
                if ((bool)rbGenderM.IsChecked)
                    gender = rbGenderM.Content.ToString();
                else
                    if ((bool)rbGenderF.IsChecked)
                    gender = rbGenderF.Content.ToString();
                stud.Gender = gender;


                string qualification = string.Empty;
                if ((bool)rbbutton3.IsChecked)
                    qualification = rbbutton3.Content.ToString();
                else
                    if ((bool)rbbutton4.IsChecked)
                    qualification = rbbutton4.Content.ToString();
                else
                    if ((bool)rbbutton5.IsChecked)
                    qualification = rbbutton5.Content.ToString();
                stud.HighQualification = qualification;

                string checkbox = string.Empty;
                // CheckBox chkbx = 
                if ((bool)chkbx1.IsChecked)
                    checkbox += chkbx1.Content.ToString() + ",";
                if ((bool)chkbx2.IsChecked)
                    checkbox += chkbx2.Content.ToString() + ",";
                if ((bool)chkbx3.IsChecked)
                    checkbox += chkbx3.Content.ToString() + ",";
                if ((bool)chkbx4.IsChecked)
                    checkbox += chkbx4.Content.ToString() + ",";
                if ((bool)chkbx5.IsChecked)
                    checkbox += chkbx5.Content.ToString();
                stud.Domain = checkbox;

                string checkbox1 = string.Empty;
                // CheckBox chkbx = 
                if ((bool)chkbx6.IsChecked)
                    checkbox1 += chkbx6.Content.ToString() + ",";
                if ((bool)chkbx7.IsChecked)
                    checkbox1 += chkbx7.Content.ToString() + ",";
                if ((bool)chkbx8.IsChecked)
                    checkbox1 += chkbx8.Content.ToString() + ",";
                if ((bool)chkbx9.IsChecked)
                    checkbox1 += chkbx9.Content.ToString() + ",";
                if ((bool)chkbx10.IsChecked)
                    checkbox1 += chkbx10.Content.ToString();
                stud.Language = checkbox1;
                //ComboBox
                stud.Location = ((ComboBoxItem)cmbox.SelectedItem).Content.ToString();

                int recordsAffected = AadharBAL.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    ShowAll();
                    ClearAll();
                }
                else
                    throw new ValidationException("Record not inserted");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string AadharNumber = txtAdhar.Text;

                int recordsAffected = AadharBAL.DeleteStudent(AadharNumber);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    ShowAll();
                    ClearAll();
                }
                else
                    throw new ValidationException("Record not deleted");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Update_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Entities stud = new Entities();

                stud.Aadhar_Number = txtAdhar.Text;
                stud.Employee_ID = Convert.ToInt32(txtEmpID.Text);
                stud.Employee_Name = txtEmpName.Text;
                stud.Dept_No = Convert.ToInt32(txtDept.Text);
                stud.Address = txtAddress.Text;
                stud.City = txtCity.Text;
                stud.State = txtState.Text;
                stud.Phone_Number = txtPhone.Text;

                int recordsAffected = AadharBAL.UpdateStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    ShowAll();
                    ClearAll();
                }
                else
                    throw new ValidationException("Record not updated");
            }
            catch (ValidationException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Count_Click(object sender, RoutedEventArgs e)
        {
            cmd = new SqlCommand("SELECT COUNT(*) FROM EmployeeDetails", con);
            con.Open();
            int count = (int)cmd.ExecuteScalar();
            con.Close();
            MessageBox.Show("Total number of Employees are :" + count);
        }

        private void Clear_Click(object sender, RoutedEventArgs e)
        {
            ClearAll();
        }
    }
}
