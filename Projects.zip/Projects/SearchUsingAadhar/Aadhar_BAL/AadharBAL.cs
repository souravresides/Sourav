﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aadhar_Entities;
using Aadhar_Exception;
using Aadhar_DAL;
using System.Text.RegularExpressions;

namespace Aadhar_BAL
{
    public class AadharBAL
    {
        public static bool ValildateStudent(Entities stud)
        {
            bool studValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                if (!Regex.IsMatch(stud.Aadhar_Number, "[0-9]{12}"))
                {
                    studValidated = false;
                    message.Append("Aadhar Number should be 12 digits\n");
                }
                if (!Regex.IsMatch(stud.Employee_ID.ToString(),"[0-9]{6}"))
                {
                    studValidated = false;
                    message.Append("Employee ID Should be 6 digits");
                }

                if (stud.Employee_Name == String.Empty)
                {
                    studValidated = false;
                    message.Append("Employee name should be provided\n");
                }
                else if (!Regex.IsMatch(stud.Employee_Name, "[A-Z][a-z]+"))
                {
                    studValidated = false;
                    message.Append("Employee name should have alphabets only\n");
                }

                if (stud.DOB == null)
                {
                    studValidated = false;
                    message.Append("Student Date of Birth should be provided\n");
                }
                if (!Regex.IsMatch(stud.Phone_Number,"([6789][0-9]{9})"))
                {
                    studValidated = false;
                    message.Append("Phone should conatain 10 digits");
                }

                if (studValidated == false)
                    throw new ValidationException(message.ToString());
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studValidated;
        }

        public static int InsertStudent(Entities stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = AadharDAL.InsertStudent(stud);
                }
                else
                    throw new ValidationException("Please provide valid Student Information");
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Entities stud)
        {
            int recordsAffected = 0;

            try
            {
                if (ValildateStudent(stud))
                {
                    recordsAffected = AadharDAL.UpdateStudent(stud);
                }
                else
                    throw new ValidationException("Please provide valid Student Information");
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(string studCode)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = AadharDAL.DeleteStudent(studCode);
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Entities SearchStudent(string studCode)
        {
            Entities stud = null;

            try
            {
                stud = AadharDAL.SearchStudent(studCode);


            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Entities> RetrieveStudent()
        {
            List<Entities> studList = null;

            try
            {
                studList = AadharDAL.RetrieveStudent();
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}