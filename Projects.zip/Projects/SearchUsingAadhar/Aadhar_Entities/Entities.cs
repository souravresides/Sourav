﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aadhar_Entities
{
    public class Entities
    {
        public string Aadhar_Number { get; set; }
        public int Employee_ID { get; set; }
        public string Employee_Name { get; set; }
        public int Dept_No { get; set; }
        public DateTime DOB { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Gender { get; set; }
        public string Phone_Number { get; set; }
        public string Domain { get; set; }
        public string HighQualification { get; set; }
        public string Language { get; set; }
        public string Location { get; set; }
    }
}
