﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Aadhar_Entities;
using Aadhar_Exception;
namespace Aadhar_DAL
{
    public class AadharDAL
    {
        public static int InsertStudent(Entities stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "InsertDetails1";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Aadhar_Number", stud.Aadhar_Number);
                cmd.Parameters.AddWithValue("@Employee_ID", stud.Employee_ID);
                cmd.Parameters.AddWithValue("@Employee_Name", stud.Employee_Name);
                cmd.Parameters.AddWithValue("@Dept_No", stud.Dept_No);
                cmd.Parameters.AddWithValue("@DOB", stud.DOB);
                cmd.Parameters.AddWithValue("@Email", stud.Email);
                cmd.Parameters.AddWithValue("@Address", stud.Address);
                cmd.Parameters.AddWithValue("@City", stud.City);
                cmd.Parameters.AddWithValue("@State", stud.State);
                cmd.Parameters.AddWithValue("@Phone_Number", stud.Phone_Number);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to update student record from database
        public static int UpdateStudent(Entities stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "UpdateDetails5";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Aadhar_Number", stud.Aadhar_Number);
                cmd.Parameters.AddWithValue("@Employee_ID", stud.Employee_ID);
                cmd.Parameters.AddWithValue("@Employee_Name", stud.Employee_Name);
                cmd.Parameters.AddWithValue("@Dept_No", stud.Dept_No);
                cmd.Parameters.AddWithValue("@Address", stud.Address);
                cmd.Parameters.AddWithValue("@City", stud.City);
                cmd.Parameters.AddWithValue("@State", stud.State);
                cmd.Parameters.AddWithValue("@Phone_Number", stud.Phone_Number);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to delete student record from database
        public static int DeleteStudent(string AadharNumber)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "DeleteDetails";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Aadhar_Number", AadharNumber);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static Entities SearchStudent(string studCode)
        {
            Entities stud = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "SearchDetails";
                cmd.Parameters.AddWithValue("@Aadhar_Number", studCode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    stud = new Entities();
                    dr.Read();
                    stud.Aadhar_Number =dr["Aadhar_Number"].ToString();
                    stud.Employee_ID = (int)dr["Employee_ID"];
                    stud.Employee_Name = dr["Employee_Name"].ToString();
                    stud.Dept_No = (int)(dr["Dept_No"]);
                    stud.DOB = Convert.ToDateTime(dr["DOB"].ToString());
                    stud.Email = dr["Email"].ToString();
                    stud.Address = dr["Address"].ToString();
                    stud.City = dr["City"].ToString();
                    stud.State = dr["State"].ToString();
                    stud.Phone_Number = dr["Phone_Number"].ToString();
                }
                else
                {
                    throw new ValidationException("Record not found");
                }
                cmd.Connection.Close();
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //Function to retrieve all student record
        public static List<Entities> RetrieveStudent()
        {
            List<Entities> studList = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "DisplayDetails";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<Entities>();
                    while (dr.Read())
                    {
                        Entities stud = new Entities();

                        stud.Aadhar_Number = dr["Aadhar_Number"].ToString();
                        stud.Employee_ID = (int)dr["Employee_ID"];
                        stud.Employee_Name = dr["Employee_Name"].ToString();
                        stud.Dept_No = (int)(dr["Dept_No"]);
                        stud.DOB = Convert.ToDateTime(dr["DOB"].ToString());
                        stud.Email = dr["Email"].ToString();
                        stud.Address = dr["Address"].ToString();
                        stud.City = dr["City"].ToString();
                        stud.State = dr["State"].ToString();
                        stud.Phone_Number = dr["Phone_Number"].ToString();


                        studList.Add(stud);
                    }
                }
                else
                    throw new ValidationException("Record not available");
                cmd.Connection.Close();
            }
            catch (ValidationException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
